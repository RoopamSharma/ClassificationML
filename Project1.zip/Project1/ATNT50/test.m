function test
	
	for i = 1:10
		j = i;
		while(j>0)
			disp(j);
			j--;
		end;
	end;
	disp('hello');
end;
